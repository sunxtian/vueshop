
export default {
    pixImg:function(val,pix='http://localhost:3333'){
        return pix+val
    }
}

