<template>
  <div>秒杀管理</div>
</template>
<script>
export default {
    data(){
        return{  }
    },
    created(){},
    methods:{},
    components:{}
}
</script>
<style scoped>
</style>