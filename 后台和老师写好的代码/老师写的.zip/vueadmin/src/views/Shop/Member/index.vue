<template>
  <div>会员管理</div>
</template>
<script>
export default {
    data(){
        return{  }
    },
    created(){},
    methods:{},
    components:{}
}
</script>
<style scoped>
</style>