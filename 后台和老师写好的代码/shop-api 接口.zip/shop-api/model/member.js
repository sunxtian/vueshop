module.exports = {
	model: {
		uid:"",
		phone:"",
		nickname:"",
		password:"",
		randstr:"",
		status:""
	},
	check: dataArr => dataArr // 不处理, 只为了不报错
}