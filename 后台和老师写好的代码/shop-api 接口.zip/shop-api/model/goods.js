module.exports = {
    model: {
        first_cateid:"",
        second_cateid:"",
        goodsname:"",
        price:"",
        market_price:"",
        img:"",
        description:"",
        specsid:"",
        specsattr:"",
        isnew:"",
        ishot:"",
        status:""
    },
    check: dataArr => dataArr // 不处理, 只为了不报错
}